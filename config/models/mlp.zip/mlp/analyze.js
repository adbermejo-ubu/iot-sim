/**
 * @global tf - TensorFlow library
 * @global model - TensorFlow current model for prediction
 */

let flows = {};

const FLOW_TIMEOUT = 60;

const dataTransform = (features) => {
    const scaler = {
        mean: [
            7.586667574904364e-5, -0.0002569646862450844,
            -0.00034248109469571097, -0.00026144530264210394,
            0.00010568871645037674, 0.00011832249847384199,
            -0.00012334874518929518, 0.000588866524575801,
            -0.00019046289428017218, -0.000383872813645464,
        ],
        std: [
            0.9999199009295211, 0.999662646579506, 0.9992552509373918,
            0.9997430875520665, 1.0210691611604972, 0.9915003923723357,
            0.9572901848819664, 1.1448989638166864, 0.9998521146396753,
            0.9980514877003535,
        ],
    };
    // Convertir los datos a tensores
    const meanTensor = tf.tensor(scaler.mean);
    const stdTensor = tf.tensor(scaler.std);
    const featuresTensor = tf.tensor(features);

    // Realizar la transformación usando la fórmula (X - mean) / std
    return featuresTensor.sub(meanTensor).div(stdTensor);
};

const updateFlow = (packet) => {
    let {
        srcIP,
        dstIP,
        srcPort,
        dstPort,
        transportProtocol: protocol,
        totalBytes: packetLength,
        payloadSize: outBytes,
        tcpFlags,
    } = packet;
    if (![6, 17].includes(protocol)) {
        srcPort = 0;
        dstPort = 0;
    }
    tcpFlags = tcpFlags ?? 0;
    const flowKey = `${srcIP}_${dstIP}_${srcPort}_${dstPort}_${protocol}`;
    const currentTime = new Date().getTime();
    const flowDuration = currentTime * 1000;

    if (flows[flowKey]) {
        const flow = flows[flowKey];
        flow.lastSeen = currentTime;
        flow.packetCount += 1;
        flow.totalBytes += packetLength;
        flow.outBytes += outBytes;
        flow.tcpFlags |= tcpFlags;
    } else {
        flows[flowKey] = {
            startTime: currentTime,
            lastSeen: currentTime,
            packetCount: 1,
            totalBytes: packetLength,
            outBytes: outBytes,
            tcpFlags: tcpFlags,
        };
    }
};

const extractFlowFeatures = () => {
    const closedFlows = [];
    const currentTime = new Date().getTime();

    for (const key in flows) {
        const flow = flows[key];

        if (currentTime - flow.lastSeen > FLOW_TIMEOUT) {
            const duration = (flow.lastSeen - flow.startTime) * 1000;
            const flowKey = key.split("_");
            const features = [
                Number(flowKey[2]), // L4_SRC_PORT
                Number(flowKey[3]), // L4_DST_PORT
                Number(flowKey[4]), // PROTOCOL
                0, // L7_PROTO (placeholder)
                flow.totalBytes, // IN_BYTES
                flow.outBytes, // OUT_BYTES
                flow.packetCount, // IN_PKTS
                flow.packetCount, // OUT_PKTS
                flow.tcpFlags, // TCP_FLAGS
                duration, // FLOW_DURATION_MILLISECONDS
            ];
            closedFlows.push(features);
            delete flows[key];
        }
    }
    return closedFlows;
};

/**
 * Function to analyze the data and return a boolean value
 *
 * @param {object} packet - The packet to be analyzed
 * @returns {boolean} - True if the packet is malicious, false otherwise
 */
function analyze(packet) {
    updateFlow(packet);
    const closedFlows = extractFlowFeatures();
    if (closedFlows.length > 0) {
        const inputData = dataTransform(closedFlows);
        const scores = model.predict(inputData).arraySync();

        console.log(`Score of ${model.name}: ${scores}`);
        return scores > 0.5;
    }
}
