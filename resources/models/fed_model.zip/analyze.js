/**
 * @global tf - TensorFlow library
 * @global model - TensorFlow current model for prediction
 */

const FLOW_TIMEOUT = 8 * 1000; // 8 seconds to close a flow
const THRESHOLD = 0.5; // threshold for attack detection
let flows = {}; // Flows object to track active flows

/**
 * This function transforms the input features to match the model's expected input.
 *
 * @param {Array} features - Array of features to be normalized
 * @returns {Array<tf.Tensor>} - Normalized tensor of features
 */
const dataTransform = (features) => {
    const scaler = {
        mean: [
            4.28023983e4, 5.93942913e3, 7.06856771, 2.35909806e1, 1.71694686e3,
            3.25870611e3, 2.10905488e1, 1.26163676e1, 2.2015899e1, 7.87464335e3,
        ],
        std: [
            1.63769802e4, 1.54159595e4, 3.28183061, 3.55981078e1, 1.9422247e5,
            1.20653889e5, 3.14940114e3, 1.5873535e3, 8.45310854, 1.30496933e5,
        ],
    };

    // Convert features to tensor
    const meanTensor = tf.tensor1d(scaler.mean);
    const stdTensor = tf.tensor1d(scaler.std);
    const featuresTensor = tf.tensor2d(features);
    // Normalized: (X - mean) / std
    const normalized = featuresTensor.sub(meanTensor).div(stdTensor);

    return normalized;
};

/**
 * Updates the flow with the given packet information.
 *
 * @param {Object} packet - The packet to update the flow with
 * @param {string} packet.srcIP - Source IP address of the packet
 * @param {number} [packet.srcPort] - Source port of the packet
 * @param {string} packet.dstIP - Destination IP address of the packet
 * @param {number} [packet.dstPort] - Destination port of the packet
 * @param {number} packet.transportProtocol - Transport protocol of the packet
 * @param {number} [packet.applicationProtocol] - Application protocol of the packet
 * @param {string} [packet.payload] - Payload of the packet
 * @param {number} packet.totalBytes - Total bytes of the packet
 * @param {number} packet.headerSize - Header size of the packet
 * @param {number} packet.payloadSize - Payload size of the packet
 * @param {Date} packet.timestamp - Timestamp of the packet
 * @param {number} packet.ttl - Time to live of the packet
 * @param {number} packet.type - ICMP message type (ECHO_REPLY = 0, ECHO_REQUEST = 8)
 * @param {number} packet.code - ICMP message code (0 = no code)
 * @param {number} packet.identifier - ICMP message identifier
 * @param {number} packet.sequence - ICMP message sequence number
 * @param {number} packet.tcpFlags - TCP flags (FIN = 1, SYN = 2, RST = 4, PSH = 8, ACK = 16, URG = 32)
 */
const updateFlow = (packet) => {
    let {
        srcIP,
        dstIP,
        srcPort,
        dstPort,
        transportProtocol: protocol,
        totalBytes: packetLength,
        payloadSize: outBytes,
        tcpFlags,
    } = packet;

    // Only consider TCP and UDP protocols for flow tracking
    if (![6, 17].includes(protocol)) {
        srcPort = 0;
        dstPort = 0;
    }
    tcpFlags = tcpFlags ?? 0;

    const flowKey = `${srcIP}_${dstIP}_${srcPort}_${dstPort}_${protocol}`;
    const currentTime = Date.now();

    if (flows[flowKey]) {
        const flow = flows[flowKey];
        flow.lastSeen = currentTime;
        flow.packetCount += 1;
        flow.totalBytes += packetLength;
        flow.outBytes += outBytes;
        flow.tcpFlags |= tcpFlags;
    } else {
        flows[flowKey] = {
            startTime: currentTime,
            lastSeen: currentTime,
            packetCount: 1,
            totalBytes: packetLength,
            outBytes: outBytes,
            tcpFlags: tcpFlags,
        };
    }
};

/**
 * Extract features from closed flows and return them as an array.
 *
 * @returns {Array} - Array of features for each closed flow
 */
const extractFlowFeatures = () => {
    const closedFlows = [];
    const currentTime = Date.now();

    for (const key in flows) {
        const flow = flows[key];

        // If the flow has not been seen for more than FLOW_TIMEOUT, consider it closed
        if (currentTime - flow.lastSeen > FLOW_TIMEOUT) {
            const duration = flow.lastSeen - flow.startTime; // en ms
            const flowKey = key.split("_");
            const features = [
                Number(flowKey[2]), // L4_SRC_PORT
                Number(flowKey[3]), // L4_DST_PORT
                Number(flowKey[4]), // PROTOCOL
                0, // L7_PROTO (placeholder)
                flow.totalBytes, // IN_BYTES
                flow.outBytes, // OUT_BYTES
                flow.packetCount, // IN_PKTS
                flow.packetCount, // OUT_PKTS (igual a IN_PKTS aquí)
                flow.tcpFlags, // TCP_FLAGS
                duration, // FLOW_DURATION_MILLISECONDS
            ];
            closedFlows.push(features);
            delete flows[key];
        }
    }
    return closedFlows;
};

/**
 * Analyzes a packet to update flows and predict if they are malicious.
 *
 * @param {Object} packet - The packet to analyze
 * @param {string} packet.srcIP - Source IP address of the packet
 * @param {number} [packet.srcPort] - Source port of the packet
 * @param {string} packet.dstIP - Destination IP address of the packet
 * @param {number} [packet.dstPort] - Destination port of the packet
 * @param {number} packet.transportProtocol - Transport protocol of the packet
 * @param {number} [packet.applicationProtocol] - Application protocol of the packet
 * @param {string} [packet.payload] - Payload of the packet
 * @param {number} packet.totalBytes - Total bytes of the packet
 * @param {number} packet.headerSize - Header size of the packet
 * @param {number} packet.payloadSize - Payload size of the packet
 * @param {Date} packet.timestamp - Timestamp of the packet
 * @param {number} packet.ttl - Time to live of the packet
 * @param {number} packet.type - ICMP message type (ECHO_REPLY = 0, ECHO_REQUEST = 8)
 * @param {number} packet.code - ICMP message code (0 = no code)
 * @param {number} packet.identifier - ICMP message identifier
 * @param {number} packet.sequence - ICMP message sequence number
 * @param {number} packet.tcpFlags - TCP flags (FIN = 1, SYN = 2, RST = 4, PSH = 8, ACK = 16, URG = 32)
 * @returns {boolean | void} - Returns true if the flow is predicted to be malicious, false if not, or void if is waiting for more packets
 */
function analyze(packet) {
    updateFlow(packet);
    const closedFlows = extractFlowFeatures();

    if (closedFlows.length === 0) return;

    const inputData = dataTransform(closedFlows);

    // Predict probability of being malicious
    const predictions = model.predict(inputData).arraySync();
    const isAttack = predictions
        .map((e) => e > THRESHOLD)
        .some((e) => e === true);

    for (const p of predictions)
        console.log(
            `${p[0] > THRESHOLD ? "🛑 ATTACK" : "✅ NORMAL"} - ${p[0]}`
        );
    return isAttack;
}
